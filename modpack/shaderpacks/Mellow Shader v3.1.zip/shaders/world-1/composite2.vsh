#version 400 compatibility
#define DIMENSION_NETHER

#include "/program/composite2.vsh"
